# Script to download and play video fullscreen

# Add error handling and logging
$ErrorActionPreference = "Continue"
$logPath = "$env:TEMP\js_log.txt"
function Log-Message {
    param([string]$message)
    Add-Content -Path $logPath -Value "$(Get-Date): $message"
}

try {
    Log-Message "Script started"
    
    # Download the video from GitHub
    $videoUrl = "https://github.com/ATisma/scripts/raw/refs/heads/master/play-video-windows/video.mp4"
    $videoPath = "$env:TEMP\video.mp4"
    
    Log-Message "Downloading video from direct source"
    
    # Use WebClient for faster downloads without progress bar
    $webClient = New-Object System.Net.WebClient
    $webClient.DownloadFile($videoUrl, $videoPath)
    
    Log-Message "Download completed, preparing to play video"
    
    # Make sure the video file exists and has content
    if (Test-Path $videoPath) {
        $fileSize = (Get-Item $videoPath).Length
        Log-Message "Video file size: $fileSize bytes"
        
        # DIRECT APPROACH: Use Windows Media Player executable directly
        $wmplayerPath = "${env:ProgramFiles(x86)}\Windows Media Player\wmplayer.exe"
        if (-not (Test-Path $wmplayerPath)) {
            $wmplayerPath = "$env:ProgramFiles\Windows Media Player\wmplayer.exe"
        }
        if (-not (Test-Path $wmplayerPath)) {
            $wmplayerPath = "wmplayer.exe" # Try to find it in PATH
        }
        
        Log-Message "Using Windows Media Player at: $wmplayerPath"
        
        # Create a batch file to launch WMP in fullscreen mode
        $batchContent = @"
@echo off
start "" /wait "$wmplayerPath" "$videoPath" /fullscreen
"@
        $batchPath = "$env:TEMP\play_video.bat"
        $batchContent | Out-File -FilePath $batchPath -Encoding ASCII
        
        Log-Message "Created batch file: $batchPath"
        
        # Execute the batch file with high priority and hidden window
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $batchPath" -WindowStyle Hidden
        
        Log-Message "Launched video player via batch file"
        
        # Try creating a shortcut as a backup method
        try {
            Log-Message "Creating backup shortcut method"
            $WshShell = New-Object -ComObject WScript.Shell
            $Shortcut = $WshShell.CreateShortcut("$env:TEMP\video_player.lnk")
            $Shortcut.TargetPath = $wmplayerPath
            $Shortcut.Arguments = """$videoPath"" /fullscreen"
            $Shortcut.Save()
            
            # Execute the shortcut
            Start-Process "$env:TEMP\video_player.lnk" -WindowStyle Hidden
            Log-Message "Launched backup shortcut method"
        }
        catch {
            Log-Message "Shortcut creation failed: $_"
        }
    }
    else {
        Log-Message "Video file not found after download"
        
        # Show error message
        $alertVbs = @'
MsgBox "System Error: File download failed!", 16, "SYSTEM ERROR"
'@
        $alertPath = "$env:TEMP\alert.vbs"
        $alertVbs | Out-File -FilePath $alertPath -Encoding ASCII
        Start-Process "wscript.exe" -ArgumentList """$alertPath""" -WindowStyle Hidden
    }
}
catch {
    Log-Message "Error occurred: $_"
    
    # Show error message if anything fails
    $alertVbs = @'
MsgBox "Critical System Error: Unexpected failure detected!", 16, "SYSTEM ERROR"
'@
    $alertPath = "$env:TEMP\alert.vbs"
    $alertVbs | Out-File -FilePath $alertPath -Encoding ASCII
    Start-Process "wscript.exe" -ArgumentList """$alertPath""" -WindowStyle Hidden
}