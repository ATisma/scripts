# Add error handling and logging
$ErrorActionPreference = "Continue"
$logPath = "$env:TEMP\js_log.txt"
function Log-Message {
    param([string]$message)
    Add-Content -Path $logPath -Value "$(Get-Date): $message"
}

try {
    Log-Message "Script started"
    
    # Download the jumpscare video
    $videoUrl = "https://drive.google.com/uc?export=download&id=1_mzfsQN5NBEqwrMRkGPnBB6MDWM-8_VN"
    $videoPath = "$env:TEMP\insomnia.mp4"
    
    Log-Message "Attempting to download video from: $videoUrl"
    
    # Using Invoke-WebRequest with a longer timeout (this worked according to the logs)
    $ProgressPreference = 'SilentlyContinue'  # Hide progress bar to speed up download
    Invoke-WebRequest -Uri $videoUrl -OutFile $videoPath -TimeoutSec 60
    
    # Check if download was successful
    if (Test-Path $videoPath) {
        $fileSize = (Get-Item $videoPath).Length
        Log-Message "Download completed. File size: $fileSize bytes"
        
        # Use a simpler approach with direct video playback
        Log-Message "Attempting simplified full screen playback"
        
        # Setup a minimal HTML file to play the video fullscreen
        $htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <title>Video</title>
    <style>
        body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; background-color: black; }
        video { width: 100%; height: 100%; object-fit: contain; }
    </style>
    <script>
        function playVideo() {
            var video = document.getElementById('player');
            video.play();
            document.documentElement.requestFullscreen();
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            // Auto click to trigger fullscreen on load
            setTimeout(function() {
                document.body.click();
            }, 500);
        });
        
        document.addEventListener('click', function() {
            var video = document.getElementById('player');
            if (video.paused) {
                playVideo();
            } else {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                }
            }
        });
        
        // Prevent escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                e.preventDefault();
                return false;
            }
        });
    </script>
</head>
<body>
    <video id="player" autoplay loop>
        <source src="$videoPath" type="video/mp4">
    </video>
</body>
</html>
"@
        
        $htmlPath = "$env:TEMP\player.html"
        $htmlContent | Out-File -FilePath $htmlPath -Encoding utf8
        Log-Message "Created HTML player: $htmlPath"
        
        # Open with default browser
        Log-Message "Opening HTML player with default browser"
        
        # Use a more direct method to open the file
        $browser = Start-Process -FilePath $htmlPath -PassThru
        
        # Keep script running to ensure it doesn't close immediately
        Log-Message "Waiting for browser process..."
        Start-Sleep -Seconds 30
        
        # Try an alternative approach if the above didn't work
        if (-not (Get-Process -Id $browser.Id -ErrorAction SilentlyContinue)) {
            Log-Message "Browser process not found, trying alternative approach"
            Start-Process "cmd.exe" -ArgumentList "/c start $htmlPath" -WindowStyle Hidden
            Start-Sleep -Seconds 30
        }
    }
    else {
        Log-Message "Video file not found after download attempt"
    }
}
catch {
    Log-Message "Error occurred: $_"
    # Keep PowerShell window open longer so the error is visible
    Start-Sleep -Seconds 30
}