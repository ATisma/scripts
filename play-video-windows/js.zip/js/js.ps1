# Script to download and play video fullscreen with maximum volume

try {
    # Download the video from GitHub
    $videoUrl = "https://github.com/ATisma/scripts/raw/refs/heads/master/play-video-windows/video.mp4"
    $videoPath = "$env:TEMP\video.mp4"
    
    # Use WebClient for faster downloads without progress bar
    $webClient = New-Object System.Net.WebClient
    $webClient.DownloadFile($videoUrl, $videoPath)
    
    # Make sure the video file exists
    if (Test-Path $videoPath) {
        # Set system volume to maximum (100%)
        try {
            # Create and run a VBS script to set the system volume to maximum
            $volumeVbs = @'
Set WshShell = CreateObject("WScript.Shell")
' Set volume to maximum
For i = 1 To 50
    WshShell.SendKeys(chr(&hAF))  ' Volume up key
Next
'@
            $volumeVbsPath = "$env:TEMP\volume.vbs"
            $volumeVbs | Out-File -FilePath $volumeVbsPath -Encoding ASCII
            
            # Run the volume script
            Start-Process "wscript.exe" -ArgumentList """$volumeVbsPath""" -WindowStyle Hidden -Wait
            
            # Clean up the volume script
            Remove-Item -Path $volumeVbsPath -Force -ErrorAction SilentlyContinue
        }
        catch {
            # Ignore errors with volume adjustment
        }
        
        # Find Windows Media Player executable
        $wmplayerPath = "${env:ProgramFiles(x86)}\Windows Media Player\wmplayer.exe"
        if (-not (Test-Path $wmplayerPath)) {
            $wmplayerPath = "$env:ProgramFiles\Windows Media Player\wmplayer.exe"
        }
        if (-not (Test-Path $wmplayerPath)) {
            $wmplayerPath = "wmplayer.exe" # Try to find it in PATH
        }
        
        # Create a batch file that sets volume to max and launches WMP in fullscreen
        $batchContent = @"
@echo off
:: Play video in fullscreen with maximum volume
start "" /wait "$wmplayerPath" "$videoPath" /fullscreen /play /close
"@
        $batchPath = "$env:TEMP\play_video.bat"
        $batchContent | Out-File -FilePath $batchPath -Encoding ASCII
        
        # Execute the batch file with hidden window
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $batchPath" -WindowStyle Hidden
        
        # Try creating a shortcut as a backup method
        try {
            $WshShell = New-Object -ComObject WScript.Shell
            $Shortcut = $WshShell.CreateShortcut("$env:TEMP\video_player.lnk")
            $Shortcut.TargetPath = $wmplayerPath
            $Shortcut.Arguments = """$videoPath"" /fullscreen"
            $Shortcut.Save()
            
            # Execute the shortcut
            Start-Process "$env:TEMP\video_player.lnk" -WindowStyle Hidden
        }
        catch {
            # Ignore shortcut creation errors
        }
    }
    else {
        # Show error message
        $alertVbs = @'
MsgBox "System Error: Critical failure detected!", 16, "SYSTEM ERROR"
'@
        $alertPath = "$env:TEMP\alert.vbs"
        $alertVbs | Out-File -FilePath $alertPath -Encoding ASCII
        Start-Process "wscript.exe" -ArgumentList """$alertPath""" -WindowStyle Hidden
    }
}
catch {
    # Show error message if anything fails
    $alertVbs = @'
MsgBox "Critical System Error: Unexpected failure detected!", 16, "SYSTEM ERROR"
'@
    $alertPath = "$env:TEMP\alert.vbs"
    $alertVbs | Out-File -FilePath $alertPath -Encoding ASCII
    Start-Process "wscript.exe" -ArgumentList """$alertPath""" -WindowStyle Hidden
}