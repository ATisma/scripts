# Script to download and play video fullscreen using Windows Media Player

# Add error handling and logging
$ErrorActionPreference = "Continue"
$logPath = "$env:TEMP\js_log.txt"
function Log-Message {
    param([string]$message)
    Add-Content -Path $logPath -Value "$(Get-Date): $message"
}

try {
    Log-Message "Script started"
    
    # Download the video from GitHub (more reliable than Google Drive)
    # Replace this URL with your own GitHub raw URL (or other reliable direct download) 
    $videoUrl = "https://github.com/ATisma/scripts/raw/refs/heads/master/play-video-windows/video.mp4"
    $videoPath = "$env:TEMP\video.mp4"
    
    Log-Message "Downloading video from direct source"
    
    # Use WebClient for faster downloads without progress bar
    $webClient = New-Object System.Net.WebClient
    $webClient.DownloadFile($videoUrl, $videoPath)
    
    Log-Message "Download completed, launching player"
    
    # Create a VBS script to play the video immediately in fullscreen
    $vbsScript = @'
Set WshShell = CreateObject("WScript.Shell")
Set oPlayer = CreateObject("WMPlayer.OCX")

' Hide any errors
On Error Resume Next

' Configure player
oPlayer.settings.autoStart = True
oPlayer.settings.enableContextMenu = False
oPlayer.settings.enableErrorDialogs = False
oPlayer.settings.volume = 100
oPlayer.stretchToFit = True
oPlayer.uiMode = "full"

' Play the video file
videoPath = WScript.Arguments(0)
oPlayer.URL = videoPath

' Force fullscreen mode
oPlayer.fullScreen = True

' Wait for a moment and force fullscreen again
WScript.Sleep 1000
oPlayer.fullScreen = True

' Keep script running
WScript.Sleep 300000
'@
    
    $vbsPath = "$env:TEMP\play_fullscreen.vbs"
    $vbsScript | Out-File -FilePath $vbsPath -Encoding ASCII
    Log-Message "Created VBS player script"
    
    # Launch the VBS script to play the video
    Start-Process "wscript.exe" -ArgumentList """$vbsPath"" ""$videoPath""" -WindowStyle Hidden
    Log-Message "Video playback initiated"
}
catch {
    Log-Message "Error occurred: $_"
    
    # Fallback to a scary message if video playback fails
    try {
        Log-Message "Attempting fallback scary message"
        
        $alertVbs = @'
MsgBox "CRITICAL ERROR: Virus detected! System integrity compromised!", 16, "SYSTEM ALERT"
'@
        $alertPath = "$env:TEMP\alert.vbs"
        $alertVbs | Out-File -FilePath $alertPath -Encoding ASCII
        
        # Launch the alert
        Start-Process "wscript.exe" -ArgumentList """$alertPath""" -WindowStyle Hidden
    }
    catch {
        Log-Message "Fallback also failed: $_"
    }
}